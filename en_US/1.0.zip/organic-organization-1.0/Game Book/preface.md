# Preface

This **Game Book** defines the rules of **Organic Organization (O²)**. 

O² aims to catalyse self-organization in a team, department or organization. 

The goal of this game is the __neverending expression of the organizational purpose__. 

Anyone who agrees to take part in this game may rely on the authorities granted by this **Game Book**, and also agree to be bound by its duties and constraints.

Everything that is not explicitly forbidden in this Game Book or in the structural records of the organization is allowed.
