# Rogue Book

Resources, cases and tools that are important for change agents working on implementing O².

## Other O² books

### [Game Book](../Game%20Book/index.md)
### [Pattern Book](../Pattern%20Book/index.md)


# Index

1. [Introduction](introduction.md)
2. ...
3. ...