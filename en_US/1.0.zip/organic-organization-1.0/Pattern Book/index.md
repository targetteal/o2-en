# Pattern Book

## Other O² books

### [Game Book](../Game%20Book/index.md)
### [Rogue Book](../Rogue%20Book/index.md)